﻿using Empresa.Ensino.Data.Context;
using Empresa.Ensino.Domain.Entities;
using Empresa.Ensino.Domain.Interfaces.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Empresa.Ensino.Data.Repositories
{
    public class UsuarioRepsitory : Repository<Usuario>, IUsuarioRepository
    {
        public UsuarioRepsitory(EmpresaDbContext context) : base(context)
        {

        }
    }
}
