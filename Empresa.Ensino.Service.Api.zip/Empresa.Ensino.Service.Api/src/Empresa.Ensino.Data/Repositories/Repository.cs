﻿using Empresa.Ensino.Data.Context;
using Empresa.Ensino.Domain.Entities;
using Empresa.Ensino.Domain.Interfaces.Repositories;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Empresa.Ensino.Data.Repositories
{
    public class Repository<TEntity> : IRepository<TEntity> where TEntity : BaseEntity, new()
    {
        protected readonly EmpresaDbContext Db;
        private DbSet<TEntity> DbSet;

        public Repository(EmpresaDbContext db)
        {
            Db = db;
            DbSet = Db.Set<TEntity>(); 
        }

        public async Task Criar(TEntity entity)
        {
            DbSet.Add(entity);
            var teste = await this.SaveChanges();
        }

        public async Task Atualizar(TEntity entity)
        {
            DbSet.Update(entity);
            await this.SaveChanges();
        }

        public async Task<TEntity> ObterPorId(Guid id)
        {
            return await DbSet.AsNoTracking().Where(x => x.Id == id).FirstOrDefaultAsync();
        }

        public async Task<IEnumerable<TEntity>> ObterTodos()
        {
            return await DbSet.AsNoTracking().ToListAsync();
        }

        public async Task Remover(Guid id)
        {
            var entity = new TEntity { Id = id };
            DbSet.Remove(entity);
            await this.SaveChanges();
        }

        public async Task<int> SaveChanges()
        {
            return await Db.SaveChangesAsync();
        }

        ////public void Dispose()
        ////{
        ////    Db?.Dispose();
        ////}
    }
}
