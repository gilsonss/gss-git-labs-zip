﻿using Empresa.Ensino.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Empresa.Ensino.Data.Mappings
{
    public class HistoricoEscolarMapping : IEntityTypeConfiguration<HistoricoEscolar>
    {
        public void Configure(EntityTypeBuilder<HistoricoEscolar> builder)
        {
            builder.HasKey(x => x.Id);

            builder.HasOne(x => x.Usuario)
                   .WithMany(y => y.HistoricoEscolares)
                   .HasForeignKey(x => x.UsuarioId);

            builder.Property(x => x.Formato)
                   .IsRequired()
                   .HasColumnType("varchar(120)");

            builder.Property(x => x.Nome)
                  .IsRequired()
                 .HasColumnType("varchar(100)");

            builder.ToTable("HistoricoEscolar");
        }
    }
}
