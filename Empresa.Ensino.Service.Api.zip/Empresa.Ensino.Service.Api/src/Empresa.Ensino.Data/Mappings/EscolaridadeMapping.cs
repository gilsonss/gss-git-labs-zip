﻿using Empresa.Ensino.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Empresa.Ensino.Data.Mappings
{
    public class EscolaridadeMapping : IEntityTypeConfiguration<Escolaridade>
    {
        public void Configure(EntityTypeBuilder<Escolaridade> builder)
        {
            builder.HasKey(x => x.Id);

            builder.HasOne(x => x.Usuario)
                   .WithMany(y => y.Escolaridades)
                   .HasForeignKey(x => x.UsuarioId);

            builder.Property(x=> x.Descricao)
                    .IsRequired()
                    .HasColumnType("varchar(1000)");

            builder.ToTable("Escolaridade");
        }
    }
}
