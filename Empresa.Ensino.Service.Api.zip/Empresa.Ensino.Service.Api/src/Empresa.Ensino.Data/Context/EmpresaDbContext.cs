﻿using Empresa.Ensino.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Empresa.Ensino.Data.Context
{
   public class EmpresaDbContext : DbContext
    {
        public EmpresaDbContext(DbContextOptions<EmpresaDbContext> options) : base(options) { }

        public DbSet<Usuario> Usuarios { get; set; }

        public DbSet<Escolaridade> Escolaridades { get; set; }

        public DbSet<HistoricoEscolar> HistoricoEscolares { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfigurationsFromAssembly(typeof(EmpresaDbContext).Assembly);
            base.OnModelCreating(modelBuilder);
        }
    
    }
}
