﻿using Empresa.Ensino.Application.AppServices;
using Empresa.Ensino.Application.Interfaces;
using Empresa.Ensino.Data.Context;
using Empresa.Ensino.Data.Repositories;
using Empresa.Ensino.Domain.Interfaces.Repositories;
using Empresa.Ensino.Domain.Interfaces.Services;
using Empresa.Ensino.Domain.Services;
using Microsoft.Extensions.DependencyInjection;

namespace Empresa.Ensino.CrossCutting.IoC
{
    public static class DependencyInjectConfiguration
    {
        public static IServiceCollection RegisterServices(this IServiceCollection services)
        {
            services.AddScoped<EmpresaDbContext>();

            #region AppServices
            services.AddScoped<IUsuarioAppService, UsuarioAppService>();
            #endregion

            #region Services
            services.AddScoped<IUsuarioService, UsuarioService>();
            #endregion

            #region Repositories
            services.AddScoped<IUsuarioRepository , UsuarioRepsitory>();
            #endregion

            return services;
        }
    }
}
