﻿using Empresa.Ensino.Application.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Empresa.Ensino.Application.Interfaces
{
    public interface IUsuarioAppService
    {
        Task Criar(UsuarioViewModel usuaurioVieModel);

        Task Atualizar(Guid Id, UsuarioViewModel usuaurioVieModel);
        
        Task<UsuarioViewModel> ObterPorId(Guid id);

        Task<IEnumerable<UsuarioViewModel>> ObterTodos();

        Task Remover(Guid id);
    }
}
