﻿using AutoMapper;
using Empresa.Ensino.Application.ViewModels;
using Empresa.Ensino.Domain.Entities;

namespace Empresa.Ensino.Application.AutoMapper
{
    public class AutoMapperConfiguration : Profile
    {
        public AutoMapperConfiguration()
        {
            CreateMap<Usuario, UsuarioViewModel>().ReverseMap();
        }
    }
}
