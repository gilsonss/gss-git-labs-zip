﻿using AutoMapper;
using Empresa.Ensino.Application.Interfaces;
using Empresa.Ensino.Application.ViewModels;
using Empresa.Ensino.Domain.Entities;
using Empresa.Ensino.Domain.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Empresa.Ensino.Application.AppServices
{
    public class UsuarioAppService : IUsuarioAppService
    {
        private readonly IMapper _mapper;
        private readonly IUsuarioService _service;


        public UsuarioAppService(IUsuarioService service, IMapper mapper)
        {
            _mapper = mapper;
            _service = service;
        }

        public async Task Criar(UsuarioViewModel usuaurioVieModel)
        {
            var usuario = _mapper.Map<Usuario>(usuaurioVieModel);
            await _service.Criar(usuario);
        }

        public async Task Atualizar(Guid Id, UsuarioViewModel usuaurioVieModel)
        {
            var usuario = await _service.ObterPorId(Id);
            if (usuario != null)
            {
                usuario.Nome = usuaurioVieModel.Nome;
                usuario.SobreNome = usuaurioVieModel.SobreNome;
                usuario.DataNascimento = usuaurioVieModel.DataNascimento;
                usuario.Email = usuaurioVieModel.Email;

                await _service.Atualizar(usuario);
            }
        }

        public async Task<UsuarioViewModel> ObterPorId(Guid id)
        {
            return _mapper.Map<UsuarioViewModel>(await _service.ObterPorId(id));
        }

        public async Task<IEnumerable<UsuarioViewModel>> ObterTodos()
        {
            return _mapper.Map<IEnumerable<UsuarioViewModel>>(
                          await _service.ObterTodos());
        }

        public async Task Remover(Guid id)
        {
            await _service.Remover(id);
        }
    }
}
