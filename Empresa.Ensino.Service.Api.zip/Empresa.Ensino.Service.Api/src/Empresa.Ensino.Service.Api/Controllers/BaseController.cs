﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Empresa.Ensino.Service.Api.Controllers
{
    [ApiController]
    public class BaseController : ControllerBase
    {
        private bool OperacaoValida()
        {
            return true;        
        }

        protected ActionResult ResponsePagOK(object result = null)
        {
            return Ok(new
            {
                success = true,
                data = result
            });
        }

            protected ActionResult CustomResponse(object result = null)
        {
            
            if (OperacaoValida())
            {
                return Ok(new
                {
                    success = true,
                    data = result
                });
            }

            return BadRequest(new
            {
                success = false,
                Errors = new List<string> { "ocorreu erro na operação " }             
            });;
        }
    }
}
