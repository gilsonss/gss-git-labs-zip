﻿
using Empresa.Ensino.Application.Interfaces;
using Empresa.Ensino.Application.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Empresa.Ensino.Service.Api.Controllers
{

    [Route("[controller]")]
    public class UsuarioController : BaseController
    {
        private readonly IUsuarioAppService _appService;

        public UsuarioController(IUsuarioAppService appService)
        {
            _appService = appService;
        }

        [HttpGet("[action]")]
        public async Task<IEnumerable<UsuarioViewModel>> ObterTodos()
        {
            return await _appService.ObterTodos();
        }

        [HttpDelete("[action]/{id}")]
        public async Task<ActionResult> Remover(Guid id)
        {
            await _appService.Remover(id);
            return ResponsePagOK(true);
        }

        [HttpPost("[action]")]
        public async Task<ActionResult> Criar([FromBody] UsuarioViewModel usuarioViewModel)
        {
            await _appService.Criar(usuarioViewModel);
            return ResponsePagOK(true);
        }

        [HttpPut("[action]/{id}")]
        public async Task<ActionResult> Atualizar(Guid Id, UsuarioViewModel usuarioViewModel)
        {
            await _appService.Atualizar(Id,usuarioViewModel);
            return ResponsePagOK(true);
        }

        [HttpGet("[action]/{id}")]
        public async Task<ActionResult<UsuarioViewModel>> ObterPorId(Guid id)
        {
            var usuario = await _appService.ObterPorId(id);
            return ResponsePagOK(usuario);
        }

    }
}
