﻿using Empresa.Ensino.Domain.Entities;
using Empresa.Ensino.Domain.Interfaces.Repositories;
using Empresa.Ensino.Domain.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Empresa.Ensino.Domain.Services
{
    public class UsuarioService : IUsuarioService
    {
        private IUsuarioRepository _usuarioRepository;

        public UsuarioService(IUsuarioRepository usuarioRepository)
        {
            _usuarioRepository = usuarioRepository;
        }

        public async Task Criar(Usuario usuario)
        {
            await  _usuarioRepository.Criar(usuario);
        }

        public async Task Atualizar(Usuario usuario)
        {
            await _usuarioRepository.Atualizar(usuario);           
        }

        public async Task<Usuario> ObterPorId(Guid id)
        {
            return await _usuarioRepository.ObterPorId(id);
        }

        public async Task<IEnumerable<Usuario>> ObterTodos()
        {
            return await _usuarioRepository.ObterTodos();
        }

        public async Task Remover(Guid id)
        {
            await _usuarioRepository.Remover(id);
        }
    }
}
