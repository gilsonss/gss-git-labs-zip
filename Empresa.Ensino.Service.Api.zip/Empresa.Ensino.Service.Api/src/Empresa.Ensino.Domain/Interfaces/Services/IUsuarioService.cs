﻿using Empresa.Ensino.Domain.Entities;
using Empresa.Ensino.Domain.Interfaces.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Empresa.Ensino.Domain.Interfaces.Services
{
    public interface IUsuarioService 
    {
        Task Criar(Usuario usuaurioVieModel);

        Task Atualizar(Usuario usuaurioVieModel);

        Task<Usuario> ObterPorId(Guid id);

        Task<IEnumerable<Usuario>> ObterTodos();

        Task Remover(Guid id);
    }
}
