﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Empresa.Ensino.Domain.Entities
{
    public class HistoricoEscolar  : BaseEntity
    {
        public string Formato { get; set; }

        public string Nome { get; set; }

        public Guid UsuarioId { get; set; }

        public virtual Usuario Usuario { get; set; }
    }
}
