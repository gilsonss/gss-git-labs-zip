﻿using System;
using System.Collections.Generic;

namespace Empresa.Ensino.Domain.Entities
{
    public class Usuario : BaseEntity
    {
        public string Nome { get; set; }

        public string SobreNome { get; set; }

        public string Email { get; set; }

        public DateTime? DataNascimento { get; set; }

        public virtual ICollection<HistoricoEscolar> HistoricoEscolares { get; set; }

        public virtual ICollection<Escolaridade> Escolaridades { get; set; }


    }
}
