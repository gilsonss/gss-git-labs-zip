import { Component } from '@angular/core';

@Component({
  selector: 'eebr-root',
  templateUrl: './app.component.html',
})
export class AppComponent {
  title = 'Empresa-Ensino-Front';
}
