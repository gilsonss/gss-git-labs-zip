import { Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { HomeComponent } from './home/home.component';
import { DetalhesUsuarioComponent } from './usuarios/detalhes-usuario/detalhes-usuario.component';
import { ItemUsuarioComponent } from './usuarios/item-usuario/item-usuario.component';
import { UsuariosComponent } from './usuarios/usuarios.component';

export const ROUTES: Routes = [
  { path: '', component: HomeComponent },
  { path: 'usuarios', component: UsuariosComponent },
  { path: 'item-usuario', component: ItemUsuarioComponent },
  {
    path: 'detalhes',
    component: DetalhesUsuarioComponent,
    pathMatch: 'full',
  },
  { path: 'about', component: AboutComponent },
];
