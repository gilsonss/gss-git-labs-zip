import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { ROUTES } from '../app/app.routes';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { HeaderComponent } from './header/header.component';
import { AboutComponent } from './about/about.component';
import { UsuariosComponent } from './usuarios/usuarios.component';
import { UsuarioService } from './usuarios/services/UsuarioService';
import { BaseService } from './service/BaseService';
import { ItemUsuarioComponent } from './usuarios/item-usuario/item-usuario.component';
import { InputComponent } from './shared/input/input.component';
import { DetalhesUsuarioComponent } from './usuarios/detalhes-usuario/detalhes-usuario.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    HeaderComponent,
    AboutComponent,
    UsuariosComponent,
    ItemUsuarioComponent,
    InputComponent,
    DetalhesUsuarioComponent,
  ],
  imports: [
    RouterModule.forRoot(ROUTES),
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
  ],
  providers: [BaseService, UsuarioService],
  bootstrap: [AppComponent],
})
export class AppModule {}
