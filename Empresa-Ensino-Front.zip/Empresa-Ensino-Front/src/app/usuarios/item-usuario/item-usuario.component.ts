import { Component, Input, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  Validators,
  AbstractControl,
} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { Usuario } from '../Models/Usuario';
import { UsuarioService } from '../services/UsuarioService';

@Component({
  selector: 'eebr-item-usuario',
  templateUrl: './item-usuario.component.html',
})
export class ItemUsuarioComponent implements OnInit {
  usuarioForm: FormGroup;
  usuario: Usuario;
  usuarioId: string;
  ehEdicao: boolean;
  acaoUsuario: string = 'Novo Cadastro';
  errors: any[] = [];

  numberPattern = /^[0-9]*$/;

  constructor(
    private formBuilder: FormBuilder,
    private usuarioService: UsuarioService,
    private router: Router,
    private routeActive: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.obterParametros();
    this.carregarForm();
  }

  saveForm() {
    let userForm = Object.assign({}, this.usuario, this.usuarioForm.value);
    if (this.ehEdicao) this.editar(userForm);
    else this.salvar(userForm);
  }

  salvar(userForm: Usuario) {
    this.usuarioService.salvar(userForm).subscribe(
      (result) => {
        this.router.navigateByUrl('/usuarios');
      },
      (msgError) => {
        this.setError(msgError);
      }
    );
  }

  editar(userForm: Usuario) {
    this.usuarioService.editar(this.usuarioId, userForm).subscribe(
      (result) => {
        this.router.navigateByUrl('/usuarios');
      },
      (msgError) => {
        this.setError(msgError);
      }
    );
  }

  obterParametros() {
    this.routeActive.queryParams.subscribe((params) => {
      this.usuarioId = params['id'];
    });

    if (this.usuarioId != undefined && this.usuarioId != null) {
      this.ehEdicao = true;
      this.acaoUsuario = 'Editar Cadastro';
      this.setValueForm(this.usuarioId);
    }
  }

  setValueForm(id: string) {
    this.usuarioService.obterPorId(id).subscribe(
      (result: Usuario) => {
        this.usuarioForm.patchValue(result);
      },
      (msgError) => {
        this.setError(msgError);
      }
    );
  }

  carregarForm() {
    this.usuarioForm = this.formBuilder.group({
      nome: this.formBuilder.control('', [
        Validators.required,
        Validators.minLength(5),
      ]),
      sobreNome: this.formBuilder.control('', [
        Validators.required,
        Validators.minLength(5),
      ]),
      dataNascimento: this.formBuilder.control('', [Validators.required]),
      email: this.formBuilder.control('', [
        Validators.required,
        Validators.pattern(this.validEmailPattern()),
      ]),
    });
  }

  validEmailPattern() {
    return /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
  }

  setError(msgError: any) {
    this.errors = msgError.error.errors;
  }
}
