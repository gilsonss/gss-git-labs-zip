import { Component, OnInit } from '@angular/core';
import { Usuario } from './Models/Usuario';
import { UsuarioService } from './services/UsuarioService';

@Component({
  selector: 'eebr-usuarios',
  templateUrl: './usuarios.component.html',
})
export class UsuariosComponent implements OnInit {
  usuarios: Usuario[] = [];
  errors: any[] = [];

  constructor(private usuarioService: UsuarioService) {}

  ngOnInit(): void {
    this.obterTodos();
  }

  obterTodos() {
    this.usuarioService.obterTodos().subscribe((resultado) => {
      this.usuarios = resultado;
    });
  }

  remover(usuario: Usuario) {
    this.usuarioService.remover(usuario).subscribe(
      (result) => {
        this.obterTodos();
      },
      (msgError) => {
        this.setError(msgError);
      }
    );
  }

  setError(msgError: any) {
    this.errors = msgError.error.errors;
  }
}
