export class Usuario {
  public id?: string;
  public nome: string;
  public sobreNome: string;
  public email: string;
  public dataNascimento?: Date;
  public escolaridadeId?: string;
  public historicoEscolarId?: string;
}
