import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Usuario } from '../Models/Usuario';
import { UsuarioService } from '../services/UsuarioService';

@Component({
  selector: 'eebr-detalhes-usuario',
  templateUrl: './detalhes-usuario.component.html',
})
export class DetalhesUsuarioComponent implements OnInit {
  usuario: Usuario;
  usuarioId: string;
  errors: any[] = [];

  constructor(
    private route: ActivatedRoute,
    private usuarioService: UsuarioService
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe((params) => {
      console.log(params);
      this.usuarioId = params['id'];
    });

    this.obterPorId(this.usuarioId);
  }

  obterPorId(usuario: string) {
    this.usuarioService.obterPorId(usuario).subscribe(
      (result: Usuario) => {
        this.usuario = result;
      },
      (msgError) => {
        this.setError(msgError);
      }
    );
  }

  setError(msgError: any) {
    this.errors = msgError.error.errors;
  }
}
