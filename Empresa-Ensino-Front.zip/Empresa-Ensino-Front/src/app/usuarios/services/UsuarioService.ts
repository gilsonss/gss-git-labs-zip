import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, pipe } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { Usuario } from '../Models/Usuario';
import { BaseService } from '../../service/BaseService';

@Injectable()
export class UsuarioService extends BaseService {
  constructor(private httpclient: HttpClient) {
    super();
  }

  obterTodos(): Observable<Usuario[]> {
    return this.httpclient
      .get<Usuario[]>(
        `${this.UrlApi}/usuario/obterTodos`,
        super.obterHeaderJson()
      )
      .pipe(catchError(super.serviceError));
  }

  salvar(usuario: Usuario): Observable<Usuario> {
    return this.httpclient
      .post(
        `${this.UrlApi}/usuario/Criar`,
        JSON.stringify(usuario),
        super.obterHeaderJson()
      )
      .pipe(map(super.extractData), catchError(super.serviceError));
  }

  editar(id: string, usuario: Usuario): Observable<Usuario> {
    return this.httpclient
      .put(
        `${this.UrlApi}/usuario/Atualizar/${id}`,
        JSON.stringify(usuario),
        super.obterHeaderJson()
      )
      .pipe(map(super.extractData), catchError(super.serviceError));
  }

  remover(usuario: Usuario): Observable<Usuario> {
    return this.httpclient
      .delete(
        `${this.UrlApi}/usuario/Remover/${usuario.id}`,
        super.obterHeaderJson()
      )
      .pipe(map(super.extractData), catchError(super.serviceError));
  }

  obterPorId(usuarioId: string): Observable<Usuario> {
    return this.httpclient
      .get(
        `${this.UrlApi}/usuario/ObterPorId/${usuarioId}`,
        super.obterHeaderJson()
      )
      .pipe(map(super.extractData), catchError(super.serviceError));
  }
}
