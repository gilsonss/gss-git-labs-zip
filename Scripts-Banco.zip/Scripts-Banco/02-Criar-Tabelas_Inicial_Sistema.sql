﻿USE 
dbEmpresaAPI
GO

BEGIN TRANSACTION;
GO

CREATE TABLE [Usuario] (
    [Id] uniqueidentifier NOT NULL,
    [Nome] varchar(50) NOT NULL,
    [SobreNome] varchar(100) NOT NULL,
    [Email] varchar(80) NOT NULL,
    [DataNascimento] datetime2 NULL,
    CONSTRAINT [PK_Usuario] PRIMARY KEY ([Id])
);
GO

CREATE TABLE [Escolaridade] (
    [Id] uniqueidentifier NOT NULL,
    [Descricao] varchar(1000) NOT NULL,
    [UsuarioId] uniqueidentifier NOT NULL,
    CONSTRAINT [PK_Escolaridade] PRIMARY KEY ([Id]),
    CONSTRAINT [FK_Escolaridade_Usuario_UsuarioId] FOREIGN KEY ([UsuarioId]) REFERENCES [Usuario] ([Id]) ON DELETE CASCADE
);
GO

CREATE TABLE [HistoricoEscolar] (
    [Id] uniqueidentifier NOT NULL,
    [Formato] varchar(120) NOT NULL,
    [Nome] varchar(100) NOT NULL,
    [UsuarioId] uniqueidentifier NOT NULL,
    CONSTRAINT [PK_HistoricoEscolar] PRIMARY KEY ([Id]),
    CONSTRAINT [FK_HistoricoEscolar_Usuario_UsuarioId] FOREIGN KEY ([UsuarioId]) REFERENCES [Usuario] ([Id]) ON DELETE CASCADE
);
GO

CREATE INDEX [IX_Escolaridade_UsuarioId] ON [Escolaridade] ([UsuarioId]);
GO

CREATE INDEX [IX_HistoricoEscolar_UsuarioId] ON [HistoricoEscolar] ([UsuarioId]);
GO

COMMIT;
GO

